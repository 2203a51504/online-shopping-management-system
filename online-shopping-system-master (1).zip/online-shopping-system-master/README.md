Online Shopping System

Online Shopping System has been developed on Java, Swing and MySQL Database. 

There are two types of users available in the project.

One is customer to search and buying the products and the second one is admin who can manage the products, stocks, orders and customer etc.
